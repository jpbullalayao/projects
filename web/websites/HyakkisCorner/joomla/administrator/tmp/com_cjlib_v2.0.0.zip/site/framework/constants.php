<?php 
/**
* @version		$Id: constants.php 01 2011-01-11 11:37:09Z maverick $
* @package		CoreJoomla.Framework
* @subpackage	Components.cjlib
* @copyright	Copyright (C) 2009 - 2010 corejoomla.com, Inc. All rights reserved.
* @author		Maverick
* @link		http://www.corejoomla.com/
* @license		License GNU General Public License version 2 or later
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

defined('CJLIB_URI') or define('CJLIB_URI', JURI::root(true).'/components/com_cjlib');

define('CJLIB_CRON_SECRET', 'cron_secret');
?>